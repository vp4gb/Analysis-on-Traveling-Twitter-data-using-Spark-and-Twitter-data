

    import org.apache.spark.{SparkConf, SparkContext}
    // this is used to implicitly convert an RDD to a DataFrame.
    //import sc.implicits._

    //import org.json4s.native.JsonFormats.parse;

    object Main {

      def main(args: Array[String]) {


        System.setProperty("hadoop.home.dir", "F:\\winutils")

        val sparkConf = new SparkConf().setAppName("SsparkTest").setMaster("local[*]").set("spark.driver.allowMultipleContexts", "true")

        val sparkcontext = new SparkContext(sparkConf)
        val sqlContext = new org.apache.spark.sql.SQLContext(sparkcontext)
        //val path = "/Users/shashibisht/Desktop/FINAL/Tweetdata.json"
        //val test5 = sqlContext.read.json(path)
        //test5.registerTempTable("Tweetdata")


        // Queries used to create the three tables.
         //val test = sqlContext.sql("select user.id as id, id as tweet_id from Tweetdata").toJSON.coalesce(1).saveAsTextFile("/Users/shashibisht/Desktop/FINAL/tweet_user_info.json")
        //test.registerTempTable("tweet_user_info")


          val path1 = "/Users/shashibisht/Desktop/FINAL/tweet_user_info.json"
          val T1 = sqlContext.read.json(path1)
          T1.registerTempTable("tweet_user_info")

        //test.show()
       // val test1 = sqlContext.sql("select user.id as id, user.name as name, user.location as location, user.followers_count as followers_count, user.verified as verified, user.profile_image_url as profile_image_url from Tweetdata").toJSON.coalesce(1).saveAsTextFile("/Users/shashibisht/Desktop/FINAL/user_info.json")
        //test1.registerTempTable("user_info")
        val path2 = "/Users/shashibisht/Desktop/FINAL/user_info.json"
        val T2 = sqlContext.read.json(path2)
        T2.registerTempTable("user_info")
        //test1.show()
        /*val test2 = sqlContext.sql("select id as tweet_id, user.favourites_count as favourites_count ,retweeted_status.retweet_count as retweet_count,created_at,user.description as description from Tweetdata where id IS NOT null AND user.favourites_count IS NOT null AND retweeted_status.retweet_count IS NOT null AND created_at IS NOT null AND user.description IS NOT null")//.toJSON.coalesce(1).saveAsTextFile("/Users/shashibisht/Desktop/tweet_info.json")*/
        //val test2 = sqlContext.sql("select id as tweet_id, user.favourites_count as favourites_count ,retweeted_status.retweet_count as retweet_count,created_at,user.description as description from Tweetdata").toJSON.coalesce(1).saveAsTextFile("/Users/shashibisht/Desktop/FINAL/tweet_info.json")
        //test2.registerTempTable("tweet_info")
        val path3 = "/Users/shashibisht/Desktop/FINAL/tweet_info.json"
        val T3 = sqlContext.read.json(path3)
        T3.registerTempTable("tweet_info")
        //test2.show()


        /******************************************************************************************************************************/
        //Q1 Based on location
        val Q2 = sqlContext.sql("select t1.location,count(t2.tweet_id) AS tweet_count from user_info t1, tweet_user_info t2 WHERE t1.id = t2.id and t1.location IS NOT null group by t1.location order by tweet_count desc limit 5")//.toJSON.coalesce(1).saveAsTextFile("/Users/shashibisht/Desktop/FINAL/Q1.json")
        Q2.show()
        /******************************************************************************************************************************/





        /******************************************************************************************************************************/
        //Quer2: Top 5 Celeb
        val Q1 = sqlContext.sql("select t1.id, t1.verified, t1.name, t2.tweet_id from user_info t1, tweet_user_info t2 where t1.id = t2.id")//.toJSON.coalesce(1).saveAsTextFile("/Users/shashibisht/Desktop/file/Q2.json")
        Q1.registerTempTable("Q1")
        val next_q1 = sqlContext.sql("select name, count( distinct tweet_id) as COUNT from Q1 where verified = false group by name order by COUNT desc limit 5")//.toJSON.coalesce(1).saveAsTextFile("/Users/shashibisht/Desktop/FINAL/Q2.json")
        next_q1.show()
        /******************************************************************************************************************************/










        /******************************************************************************************************************************/
        //Q3 Month when travelling is preferred
        val Q3 =  sqlContext.sql("select substring(created_at,5,3) as DATE from tweet_info")
        Q3.registerTempTable("Month")
       val Q3_next = sqlContext.sql("select DATE, count (*) as COUNT from Month where DATE IS NOt null group by DATE order by COUNT desc")//.toJSON.coalesce(1).saveAsTextFile("/Users/shashibisht/Desktop/FINAL/Q3.json")
        Q3_next.show()
        /******************************************************************************************************************************/





        /******************************************************************************************************************************/
        //query 4
        val Q4 = sqlContext.sql("select description from tweet_info where description like '%alone%' OR description like '%group%'")
        Q4.registerTempTable("Tarvel_Preference")
        val nextq4 = sqlContext.sql("SELECT CASE WHEN description like '%alone%' THEN 'PERFER_TO_TRAVEL_ALONE'"+
                                     "WHEN description like '%group%' THEN 'PERFER_TO_TRAVEL_IN_GROUP'"+
                                     "END AS tarvelling_preference from Tarvel_Preference")
        nextq4.registerTempTable("nextQ4")
        val next_q4_2 = sqlContext.sql("select tarvelling_preference, count(*) as COUNT from nextQ4 group by tarvelling_preference order by COUNT desc")//.toJSON.coalesce(1).saveAsTextFile("/Users/shashibisht/Desktop/FINAL/Q4.json")
        next_q4_2.show()
        /******************************************************************************************************************************/





        /******************************************************************************************************************************/
        //Query to find destinations where ppl prefer to travel :
       val Q5 = sqlContext.sql("select description from tweet_info where description like '%Beach%' or description like '%Mountain%' or description like '%valley%' or description like '%Dessert%' or description like '%Landsacpe%'")
        Q5.registerTempTable("Destinations")
        val NextQ5 = sqlContext.sql(
          "SELECT CASE WHEN description like '%Beach%' THEN 'BEACHES'" +
            "WHEN description like '%Mountain%' THEN 'MOUNTAINS'" +
            "WHEN description like '%valley%' THEN 'VALLEYS'" +
            "WHEN description like '%Dessert%' THEN 'Desserts'" +
            "WHEN description LIKE '%Landscape%' THEN 'LANDSCAPE'" +
            "END AS Favourite_Destinations from Destinations where description is not null ")
        NextQ5.registerTempTable("final")
        val test3 = sqlContext.sql("select Favourite_Destinations, Count(*) as Count from final where Favourite_Destinations is not null group by Favourite_Destinations order by  Count DESC")//.toJSON.coalesce(1).saveAsTextFile("/Users/shashibisht/Desktop/FINAL/Q5.csv")
        test3.show()
        /******************************************************************************************************************************/




        /******************************************************************************************************************************/
        /*Query 6: Query to find count of celeb and non celeb accounts.*/
        val q6 = sqlContext.sql("select verified, count(distinct id) as COUNT from user_info where verified is not NULL group by verified")//.toJSON.coalesce(1).saveAsTextFile("/Users/shashibisht/Desktop/FINAL/Q6.json")
        q6.show()
        /******************************************************************************************************************************/


      }


  }
