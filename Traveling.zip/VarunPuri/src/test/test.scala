/**
  * Created by shashibisht on 4/1/16.
  */


import org.apache.spark.rdd.RDD
import org.apache.spark.{SparkConf, SparkContext}



//import org.json4s.native.JsonFormats.parse;

object   Main {



  def  main(args: Array[String]) {

    //val filters = args

    System.setProperty("hadoop.home.dir", "F:\\winutils")

    val sparkConf = new SparkConf().setAppName("SsparkTest").setMaster("local[*]").set("spark.driver.allowMultipleContexts", "true")

    val sparkcontext = new SparkContext(sparkConf)

    //Create a Streaming COntext with 2 second window
    // val sparkstreamingcontext = new StreamingContext(sparkConf, Seconds(5))

    val sqlContext = new org.apache.spark.sql.SQLContext(sparkcontext)

    val path = "/Users/shashibisht/Desktop/1.json"

    val df = sqlContext.read.json(path)

    //    df.show()
    //    df.printSchema()

    //    df.select(df("user").printSchema()
    //      df.select(df("user.name"), df("user.location"), df("user.friends_count")).show()

    df.registerTempTable("mytableNew")
    //    df.sqlContext.sql("select user.name, user.location from mytableNew where user.name IS NOT null AND user.location IS NOT null").collect().foreach(println)

    df.sqlContext.sql("select user.name, user.location from mytableNew toJSON.saveAsTextFile("/Users/shashibisht/Desktop/abcOutput19.json")

    //test.write.text("/Users/shashibisht/Desktop/pbd/output.txt")

    //    val table = df.registerTempTable("mytable")

    //    DataFrame dataframe = sqlContext.sql("select user.created_at from mytable")
    //    val test = sqlContext.sql("select user.created_at from mytable")
    //
    //    val op=sqlContext.sql("select count(*) from people")
    //*val c=op.collect()
    //*val rdd=sc.parallelize(c)
    //*  rdd.saveAsTextFile("/home/cloudera/op")

    //test saveAsTextFile "/home/puri1513/Desktop/FinalStuff/output"
    //  test.show(100)
    // val tests = test.filter("created_at").dropDuplicates()
    /*  test.foreach(row=>
      {



      })*/



    /* var Data = ArrayBuffer[String]()


     test.foreach(rdd=>
     {
       Data += rdd.toString()

     })


 Data.foreach(s=>(println(s)))*/

    //test.foreach(row =>
    //{

    //println(row.toString())
    //})





    //test.show()


  }
      }
/**
  * Created by shashibisht on 4/3/16.
  */

